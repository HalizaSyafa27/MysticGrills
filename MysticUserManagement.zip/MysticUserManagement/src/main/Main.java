package main;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableSelectionModel;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application implements EventHandler<ActionEvent> {

	Scene scene;
	
	BorderPane borderContainer;
	GridPane gridContainer;
	FlowPane flowContainer;
	TableView<User> userTable;
	
	Label userIdLbl, usernameLbl, userRoleLbl;
	TextField userIdField, usernameField;
	ComboBox<String> roleBox;
	Button removeBtn, changeBtn;
	
	ScrollPane scrollPane;
	Connect connect = Connect.getInstance();
	
	public void initialize() {
		
		borderContainer = new BorderPane();
		gridContainer = new GridPane();
		flowContainer = new FlowPane();
		
		userIdLbl = new Label ("User ID");
		usernameLbl = new Label("Username");
		userRoleLbl = new Label("Role");
		
		userIdField = new TextField();
		userIdField.setDisable(true);
		
		usernameField = new TextField();
		usernameField.setDisable(true);
		
		roleBox = new ComboBox<>();
		
		removeBtn = new Button("Remove User");
		changeBtn = new Button("Change Role");
		
		userTable = new TableView<User>();
		
		scrollPane = new ScrollPane();
		scrollPane.setContent(borderContainer);
		scrollPane.setFitToWidth(true);
		
		scene = new Scene(scrollPane, 800, 400);
	}

	public void addComponent() {
		
		roleBox.getItems().add("Admin");
		roleBox.getItems().add("Chef");
		roleBox.getItems().add("Waiter");
		roleBox.getItems().add("Cashier");
		roleBox.getItems().add("Customer");
		roleBox.getSelectionModel().clearSelection();
		
		gridContainer.add(userIdLbl, 0, 0);
		gridContainer.add(usernameLbl, 0, 1);
		gridContainer.add(userRoleLbl, 0, 2);
		
		gridContainer.add(userIdField, 1, 0);
		gridContainer.add(usernameField, 1, 1);
		gridContainer.add(roleBox, 1, 2);
		
		flowContainer.getChildren().add(removeBtn);
		flowContainer.getChildren().add(changeBtn);
		gridContainer.add(flowContainer, 1, 3);
		
		borderContainer.setTop(gridContainer);
		borderContainer.setBottom(userTable);
	}
	
	public void arrangeComponent() {
		BorderPane.setAlignment(gridContainer, Pos.CENTER);
		
		borderContainer.setPadding(new Insets(10));
		gridContainer.setAlignment(Pos.CENTER);
		gridContainer.setVgap(10);
		gridContainer.setHgap(15);
		flowContainer.setAlignment(Pos.CENTER_LEFT);
		flowContainer.setHgap(5);
		
		usernameLbl.setMinWidth(50);
		userRoleLbl.setMinWidth(50);
		
		usernameField.setMaxWidth(250);
		roleBox.setMaxWidth(250);
	}
	
	@SuppressWarnings("unchecked")
	private void setTable() {
		
		TableColumn<User, Integer> idColumn = new TableColumn<User, Integer>("ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<User, Integer>("id"));  //bwt nambahin data ke table
		idColumn.setMinWidth(scrollPane.getWidth() / 3);
		
		TableColumn<User, String> nameColumn = new TableColumn<User, String>("Username");
		nameColumn.setCellValueFactory(new PropertyValueFactory<User, String>("username"));  //bwt nambahin data ke table
		nameColumn.setMinWidth(scrollPane.getWidth() / 3);
		
		TableColumn<User, String> roleColumn = new TableColumn<User, String>("Role");
		roleColumn.setCellValueFactory(new PropertyValueFactory<User, String>("role"));  //bwt nambahin data ke table
		roleColumn.setMinWidth(scrollPane.getWidth() / 3);
		
		userTable.getColumns().addAll(idColumn, nameColumn, roleColumn);
		userTable.setOnMouseClicked(tableMouseEvent());
	}
	
	private void setEventHandler() {
		removeBtn.setOnAction(this);
		changeBtn.setOnAction(this);
	}
	
	private EventHandler<MouseEvent> tableMouseEvent(){
		return new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				TableSelectionModel<User> tableSelectionModel = userTable.getSelectionModel();
				tableSelectionModel.setSelectionMode(SelectionMode.SINGLE);
				User user = tableSelectionModel.getSelectedItem();
				
				userIdField.setText(String.valueOf(user.getId()));
				usernameField.setText(user.getUsername());
				roleBox.setValue(user.getRole());
			}
		};
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		initialize();
		addComponent();
		arrangeComponent();
		setEventHandler();
		setTable();
		getData();
		stage.setTitle("User Management");
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}
	
	@Override
	public void handle(ActionEvent e) {
		
		if(e.getSource() == removeBtn) {
			int id = Integer.parseInt(userIdField.getText());
			
			String query = String.format(
					"DELETE FROM user\n"
					+ "WHERE id = %s", id);
			
			connect.execUpdate(query);
			refreshTable();
			
		} else if (e.getSource() == changeBtn) {	//change role button anggep aja update
			
			String role = roleBox.getValue();
			int id = Integer.parseInt(userIdField.getText());
			
			String query = String.format(
					"UPDATE user\n"
					+ "SET Role = '%s'\n"
					+ "WHERE ID = %d", role, id);
			
			connect.execUpdate(query);
			refreshTable();
		}
		refreshAllValue();
	}
	
	private void refreshAllValue() {
		userIdField.setText("");
		usernameField.setText("");
		roleBox.setValue(null);
	}
	
	private void getData() {
		String query = "SELECT * FROM user";
		connect.rs = connect.execQuery(query);
		
		try {
			while(connect.rs.next()) {
				Integer id = connect.rs.getInt("ID");
				String name = connect.rs.getString("Username");
				String role = connect.rs.getString("Role");
				userTable.getItems().add(new User(id, name, role));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void refreshTable() {
		userTable.getItems().clear();
		getData();
		
		ObservableList<User> userObs = FXCollections.observableArrayList(userTable.getItems());
		userTable.setItems(userObs);
	}

}
