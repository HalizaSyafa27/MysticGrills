package main;

import database.Connect;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableSelectionModel;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Menu;

public class Main extends Application implements EventHandler<ActionEvent>{
	
	Scene scene;
	
	BorderPane borderContainer;
	GridPane gridContainer;
	FlowPane flowContainer;
	TableView<Menu> menuTable;
	
	Label menuIdLbl, menuNameLbl, menuDescLbl, menuPriceLbl;
	TextField menuIdField, menuNameField, menuDescField, menuPriceField;
	Button updateButton, addButton, deleteButton;
	
	ScrollPane scrollPane;
	Connect connect = Connect.getInstance();
	
	//Initialize komponen yang ada di dalem container nnti
	public void initialize() {
		
		borderContainer = new BorderPane();
		gridContainer = new GridPane();
		flowContainer = new FlowPane();
		
		menuIdLbl = new Label ("Menu ID");
		menuNameLbl = new Label("Menu Name");
		menuDescLbl = new Label("Description");
		menuPriceLbl = new Label("Price");
		
		menuIdField = new TextField();
		menuIdField.setDisable(true);
		menuNameField = new TextField();
		menuDescField = new TextField();
		menuPriceField = new TextField();
		
		updateButton = new Button("Update Menu");
		addButton = new Button("Add Menu");
		deleteButton = new Button("Delete Menu");
		
		menuTable = new TableView<Menu>();
		
		scrollPane = new ScrollPane();
		scrollPane.setContent(borderContainer);
		scrollPane.setFitToWidth(true);
		
		scene = new Scene(scrollPane, 800, 400);
	}
	
	//masukin komponen" yg udh di initialize ke container
	public void addComponent() {		
		
		gridContainer.add(menuIdLbl, 0, 0);
		gridContainer.add(menuNameLbl, 0, 1);
		gridContainer.add(menuDescLbl, 0, 2);
		gridContainer.add(menuPriceLbl, 0, 3);
		
		gridContainer.add(menuIdField, 1, 0);
		gridContainer.add(menuNameField, 1, 1);
		gridContainer.add(menuDescField, 1, 2);
		gridContainer.add(menuPriceField, 1, 3);
		
		flowContainer.getChildren().add(updateButton);
		flowContainer.getChildren().add(addButton);
		flowContainer.getChildren().add(deleteButton);
		gridContainer.add(flowContainer, 1, 4);
		
		borderContainer.setTop(gridContainer);
		borderContainer.setCenter(menuTable);
	}
	
	//atur" komponen biar rapih
	public void arrangeComponent() {
		BorderPane.setAlignment(gridContainer, Pos.CENTER);

		
		//alignments
		borderContainer.setPadding(new Insets(10));
		gridContainer.setAlignment(Pos.CENTER);
		gridContainer.setVgap(10);
		gridContainer.setHgap(5);
		flowContainer.setAlignment(Pos.CENTER_LEFT);
		flowContainer.setHgap(5);
		
		//Textfield + Label widths
		menuIdField.setMaxWidth(250);
		menuNameField.setMaxWidth(250);
		menuDescField.setMaxWidth(250);
		menuPriceField.setMaxWidth(250);
		
		menuIdLbl.setMinWidth(50);
		menuNameLbl.setMinWidth(50);
		menuDescLbl.setMinWidth(50);
		menuPriceLbl.setMinWidth(50);
		
	}
	
	//atur" table buat menuTable
	@SuppressWarnings("unchecked")
	private void setTable() {
		TableColumn<Menu, Integer> idColumn = new TableColumn<Menu, Integer>("Menu ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<Menu, Integer>("id"));  //bwt nambahin data ke table
		idColumn.setMinWidth(scrollPane.getWidth() / 4);
		
		TableColumn<Menu, String> nameColumn = new TableColumn<Menu, String>("Menu Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<Menu, String>("name"));  //bwt nambahin data ke table
		nameColumn.setMinWidth(scrollPane.getWidth() / 4);
		
		TableColumn<Menu, String> descColumn = new TableColumn<Menu, String>("Description");
		descColumn.setCellValueFactory(new PropertyValueFactory<Menu, String>("desc"));
		descColumn.setMinWidth(scrollPane.getWidth() / 4);
		
		TableColumn<Menu, Integer> priceColumn = new TableColumn<Menu, Integer>("Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<Menu, Integer>("price"));
		priceColumn.setMinWidth(scrollPane.getWidth() / 4);
		
		menuTable.getColumns().addAll(idColumn, nameColumn, descColumn, priceColumn);
		menuTable.setOnMouseClicked(tableMouseEvent());
	}
	
	//biar buttonny bs jalan pake ini
	private void setEventHandler() {
		updateButton.setOnAction(this);
		addButton.setOnAction(this);
		deleteButton.setOnAction(this);
	}
	
	private EventHandler<MouseEvent> tableMouseEvent(){
		return new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				TableSelectionModel<Menu> tableSelectionModel = menuTable.getSelectionModel();
				tableSelectionModel.setSelectionMode(SelectionMode.SINGLE);
				Menu menu = tableSelectionModel.getSelectedItem();
				
				menuIdField.setText(String.valueOf(menu.getId()));
				menuNameField.setText(menu.getName());
				menuDescField.setText(menu.getDesc());
				menuPriceField.setText(String.valueOf(menu.getPrice()));
			}
		};
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		initialize();
		addComponent();
		arrangeComponent();
		setEventHandler();
		setTable();
		getData();
		stage.setTitle("Menu Item Management");
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	//buat logic buttonny
	@Override
	public void handle(ActionEvent e) {
		
		if(e.getSource()== updateButton) {
			String name = menuNameField.getText();
			String desc = menuDescField.getText();
			int price = Integer.parseInt(menuPriceField.getText());
			int id = Integer.parseInt(menuIdField.getText());
			
			String query = String.format(
					"UPDATE menu\n"
					+ "SET Name = '%s', Description = '%s', Price = %d\n"
					+ "WHERE ID = %d", name, desc, price, id);
			
			connect.execUpdate(query);
			refreshTable();
			
		} else if(e.getSource()== addButton) {	//Buat nambahin data ke dalam database
			
			String name = menuNameField.getText();
			String desc = menuDescField.getText();
			Integer price = Integer.parseInt(menuPriceField.getText());
			
			String query = String.format("INSERT INTO menu (Name, Description, Price) VALUES ('%s', '%s', %d)", name, desc, price);
	        connect.execUpdate(query);
			
			//load ulang tablenya
			refreshTable();
			
		} else if(e.getSource() == deleteButton) {
			
			int id = Integer.parseInt(menuIdField.getText());
			
			String query = String.format(
					"DELETE FROM menu\n"
					+ "WHERE ID = %d", id);
			
			connect.execUpdate(query);
			refreshTable();
			
		}
		refreshAllValue();
	}
	
	//ngambil data dari Database
	private void getData() {
		
		String query = "SELECT * FROM menu";
		connect.rs = connect.execQuery(query);
		
		try {
			while(connect.rs.next()) {
				Integer id = connect.rs.getInt("ID");
				String name = connect.rs.getString("Name");
				String desc = connect.rs.getString("Description");
				Integer price = connect.rs.getInt("Price");
				menuTable.getItems().add(new Menu(id, name, desc, price));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void refreshAllValue() {
		menuIdField.setText("");
		menuNameField.setText("");
		menuDescField.setText("");
		menuPriceField.setText("");
	}
	
	private void refreshTable() {
		menuTable.getItems().clear();
		getData();
		
		ObservableList<Menu> menuObs = FXCollections.observableArrayList(menuTable.getItems());
		menuTable.setItems(menuObs);
	}

}